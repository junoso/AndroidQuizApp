package com.example.quizquestion;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.Button;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class QuizActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private RecyclerView recyclerView;
    private QuizAdapter quizAdapter;
    private List<QAItem> qaList;
    private Button buttonSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        dbHelper = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.recyclerViewQuiz);
        buttonSubmit = findViewById(R.id.buttonSubmit);

        qaList = new ArrayList<>();
        quizAdapter = new QuizAdapter(qaList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(quizAdapter);

        loadQAData();

        buttonSubmit.setOnClickListener(v -> submitAnswers());
    }

    private void loadQAData() {
        Cursor cursor = dbHelper.getAllQA();
        if (cursor.moveToFirst()) {
            do {
                String question = cursor.getString(cursor.getColumnIndex("question"));
                String optionA = cursor.getString(cursor.getColumnIndex("option_a"));
                String optionB = cursor.getString(cursor.getColumnIndex("option_b"));
                String optionC = cursor.getString(cursor.getColumnIndex("option_c"));
                String optionD = cursor.getString(cursor.getColumnIndex("option_d"));
                String correctAnswer = cursor.getString(cursor.getColumnIndex("correct_answer"));

                QAItem qaItem = new QAItem(question, optionA, optionB, optionC, optionD, correctAnswer);
                qaList.add(qaItem);
            } while (cursor.moveToNext());
        }
        cursor.close();

        quizAdapter.notifyDataSetChanged();
    }

    private void submitAnswers() {
        int score = 0;
        HashMap<Integer, String> selectedAnswers = quizAdapter.getSelectedAnswers();

        for (int i = 0; i < qaList.size(); i++) {
            String selectedAnswer = selectedAnswers.get(i);
            if (selectedAnswer != null && selectedAnswer.equals(qaList.get(i).getCorrectAnswer())) {
                score++;
            }
        }
        Toast.makeText(this, "Your score: " + score + "/" + qaList.size(), Toast.LENGTH_SHORT).show();
    }
}