package com.example.quizquestion;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.HashMap;
import java.util.List;

public class QuizAdapter extends RecyclerView.Adapter<QuizAdapter.QuizViewHolder> {
    private List<QAItem> qaList;
    private HashMap<Integer, String> selectedAnswers = new HashMap<>();

    public QuizAdapter(List<QAItem> qaList) {
        this.qaList = qaList;
    }

    @Override
    public QuizViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_quiz, parent, false);
        return new QuizViewHolder(view);
    }

    @Override
    public void onBindViewHolder(QuizViewHolder holder, int position) {
        QAItem qaItem = qaList.get(position);
        holder.questionTextView.setText(qaItem.getQuestion());

        holder.radioGroup.clearCheck();

        holder.optionA.setText(qaItem.getOptionA());
        holder.optionB.setText(qaItem.getOptionB());
        holder.optionC.setText(qaItem.getOptionC());
        holder.optionD.setText(qaItem.getOptionD());

        holder.radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            String selectedAnswer = "";
            if (checkedId == R.id.radioA) {
                selectedAnswer = "A";
            } else if (checkedId == R.id.radioB) {
                selectedAnswer = "B";
            } else if (checkedId == R.id.radioC) {
                selectedAnswer = "C";
            } else if (checkedId == R.id.radioD) {
                selectedAnswer = "D";
            }
            selectedAnswers.put(position, selectedAnswer); // Store the selected answer
        });
    }

    @Override
    public int getItemCount() {
        return qaList.size();
    }

    public HashMap<Integer, String> getSelectedAnswers() {
        return selectedAnswers;
    }

    static class QuizViewHolder extends RecyclerView.ViewHolder {
        TextView questionTextView;
        RadioGroup radioGroup;
        RadioButton optionA, optionB, optionC, optionD;

        public QuizViewHolder(View itemView) {
            super(itemView);
            questionTextView = itemView.findViewById(R.id.textQuestion);
            radioGroup = itemView.findViewById(R.id.radioGroup);
            optionA = itemView.findViewById(R.id.radioA);
            optionB = itemView.findViewById(R.id.radioB);
            optionC = itemView.findViewById(R.id.radioC);
            optionD = itemView.findViewById(R.id.radioD);
        }
    }
}