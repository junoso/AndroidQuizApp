package ict.thei.lawtest.Data;

public class DataContent {
    public static final String[] QUESTION = new String[]{
            "In a case over which jurisdiction is exercised pursuant to <National " +
                    "Security Law> Article 55 of this Law, any person who has information " +
                    "pertaining to an offence endangering national security under this Law is " +
                    "___",
            "The provisions in <National Security Law> Articles 1 and 12 of the Basic " +
                    "Law of the Hong Kong Special Administrative Region on the legal status of " +
                    "the Hong Kong Special Administrative Region are the ___ in the Basic Law. " +
                    "No institution, organisation or individual in the Region shall contravene " +
                    "these provisions in exercising their rights and freedoms.",
            "Carrie Lam Cheng Yuet-ngor, the Chief Executive of the Hong Kong Special " +
                    "Administrative Region, hereby announce that the Law of the People's " +
                    "Republic of China on Safeguarding National Security in the Hong Kong " +
                    "Special Administrative Region listed in the attached schedule shall be" +
                    "implemented in the Hong Kong Special Administrative Region from ___ on " +
                    "June 30, 2020.",
            "The Financial Secretary of the Hong Kong Special Administrative Region " +
                    "shall, upon approval of the Chief Executive, appropriate from the general " +
                    "revenue a special fund to meet the expenditure for safeguarding national " +
                    "security and approve the establishment of relevant posts, which are not " +
                    "subject to any restrictions in the ___ in the Region. The Financial Secretary " +
                    "shall submit an annual report on the control and management of the fund " +
                    "for this purpose to the Legislative Council of the Hong Kong Special " +
                    "Administrative Region.",
            "In criminal proceedings in the Court of First Instance of the High Court " +
                    "concerning offences endangering national security, the Secretary for " +
                    "Justice may issue a certificate directing that the case shall be tried " +
                    "without a jury on the grounds of, among others, the protection of State " +
                    "secrets, involvement of foreign factors in the case, and the protection of " +
                    "personal safety of jurors and their family members. Where the Secretary " +
                    "for Justice has issued the certificate, the case shall be tried in the Court of " +
                    "First Instance without a jury by a panel of ___ judges.",
            "The power of interpretation of this Law shall be vested in the ___",
            "Which of the following is incorrect: " +
                    "(i) Law enforcement, judicial agencies and their personnel or law " +
                    "enforcement, judicial agencies and their personnel handling other crimes " +
                    "endangering national security shall keep confidential any state secrets " +
                    "they become aware of during the case handling process. " +
                    "(ii) Lawyers do not need to keep confidential any state secrets they " +
                    "become aware of during their practice. (iii) Relevant institutions, " +
                    "organizations and individuals cooperating with the case handling shall " +
                    "keep confidential any relevant information about the case.",
            "The Department of Justice of the Hong Kong Special Administrative " +
                    "Region shall establish a specialised prosecution division responsible for " +
                    "the prosecution of offences endangering national security and other " +
                    "related legal work. The prosecutors of this division shall be appointed by " +
                    "the Secretary for Justice after obtaining the consent of the ___ of the Hong " +
                    "Kong Special Administrative Region.",
            "According to Article 6 of the National Security Law, It is the common " +
                    "responsibility of all the people of China, including the people of Hong " +
                    "Kong, to safeguard the ___ of the People's Republic of China.",
            "The trial shall be conducted in an open court. When circumstances arise " +
                    "such as the trial involving State secrets or public order, all or part of the " +
                    "trial shall be ___ but the judgment shall be delivered in an open court",
            "The Hong Kong Special Administrative Region shall establish the ___ .The " +
                    "Committee shall be responsible for affairs relating to and assume primary " +
                    "responsibility for safeguarding national security in the Region. It shall be " +
                    "under the supervision of and accountable to the Central People's " +
                    "Government.",
            "According to the National Security Law of the People's Republic of China d" +
                    "in the Hong Kong Special Administrative Region, when should residents of " +
                    "the Hong Kong Special Administrative Region legally sign documents to " +
                    "confirm or swear allegiance to the Basic Law of the Hong Kong Special " +
                    "Administrative Region of the People's Republic of China and pledge loyalty " +
                    "to the Hong Kong Special Administrative Region of the People's Republic " +
                    "of China?",
            "The cases under the jurisdiction of the Office for Safeguarding National " +
                    "Security of the Central People's Government in the Hong Kong Special " +
                    "Administrative Region should meet the conditions stipulated in Article 55 " +
                    "of the Hong Kong National Security Law, and then...",
            "The Hong Kong Special Administrative Region shall complete, as early as " +
                    "possible, legislation for ___ as stipulated in the Basic Law of the Hong " +
                    "Kong Special Administrative Region and shall refine relevant laws.",
            "Which of the following is the full name of the Hong Kong National " +
                    "Security Law?",
            "Which of the following is considered a crime under the National Security " +
                    "Law: (i) Manipulating or sabotaging Hong Kong Special Administrative " +
                    "Region elections and potentially causing serious consequences; " +
                    "(ii) Imposing sanctions, blockades, or other hostile actions against Hong " +
                    "Kong Special Administrative Region or the People's Republic of China; " +
                    "(iii) Inciting hatred among Hong Kong Special Administrative Region " +
                    "residents towards the Central People's Government or the Hong Kong " +
                    "Special Administrative Region Government through illegal means and " +
                    "potentially causing serious consequences.",
            "National Security Law shall ___ where provisions of the local laws of the " +
                    "Hong Kong Special Administrative Region are inconsistent with this Law.",
            "The working departments of the Office shall establish mechanisms for " +
                    "collaboration with the relevant authorities of the Region responsible for " +
                    "safeguarding national security to enhance ___",
            "The Central People's Government shall establish in the Hong Kong Special " +
                    "Administrative Region an ___.The office shall perform its mandate for " +
                    "safeguarding national security and exercise relevant powers in " +
                    "accordance with the law.",
            "The ___ has an overarching responsibility for national security affairs " +
                    "relating to the Hong Kong Special Administrative Region.",
            "The ___ has an overarching responsibility for national security affairs " +
                    "relating to the Hong Kong Special Administrative Region.",
            "Which of the following is not a traditional national security field?",
            "What are the items included in the traditional" +
                    "national security field?",
            "The principle of ___ shall be adhered to in preventing, suppressing, and " +
                    "imposing punishment for offences endangering national security. A " +
                    "person who commits an act which constitutes an offence under the law " +
                    "shall be convicted and punished in accordance with the law. No one shall " +
                    "b" +
                    "be convicted and punished for an act which does not constitute an " +
                    "offence under the law.",
            "If the criminal act or result occurs within the Hong Kong Special " +
                    "Administrative Region, it is considered a crime within the Hong Kong" +
                    "Special Administrative Region. Which of the following is included:" +
                    "(i) Ships registered in the Hong Kong Special Administrative Region" +
                    "(ii) Aircraft registered in the Hong Kong Special Administrative Region" +
                    "(iii) High-speed trains registered in the Hong Kong Special Administrative " +
                    "Region",
            "The head of the department for safeguarding national security of the " +
                    "Hong Kong Police Force shall be appointed by the Chief Executive. The " +
                    "Chief Executive shall seek in writing the opinion of the ___",
            "On what grounds can the Secretary for Justice issue a certificate directing " +
                    "that a relevant lawsuit does not need to be tried with a jury?",
            "Which of the following is a traditional national security field?",
            "The Hong Kong Special Administrative Region shall establish the " +
                    "Committee for Safeguarding National Security. The Committee shall be " +
                    "responsible for affairs relating to and assume primary responsibility for " +
                    "safeguarding national" +
                    "security in the Region. It shall be under the supervision of and accountable " +
                    "to the ___",
            "The National Security Law for the Hong Kong Special Administrative " +
                    "Region has been incorporated into Annex ___ of the Basic Law of the Hong " +
                    "Kong Special Administrative Region in the form of a national law.",
            "The Hong Kong Special Administrative Region shall strengthen its work on " +
                    "safeguarding national security and prevention of terrorist activities. The " +
                    "Government of the Hong Kong" +
                    "Special Administrative Region shall take necessary measures to " +
                    "strengthen ___ over matters concerning national security, including those " +
                    "relating to schools, universities, social organisations, the media, and the" +
                    "internet.",
            "Which of the following rights is guaranteed under the Hong Kong National " +
                    "Security Law:",
            "The head of the department for safeguarding national security of the " +
                    "Hong Kong Police Force shall be appointed by the ___",
            "What is the role of the Department of Justice in the Hong Kong Special " +
                    "Administrative Region in relation to the national security law, including: (i)" +
                    "being responsible for prosecuting crimes that endanger national security " +
                    "and other related legal matters, (ii) issuing certificates instructing that " +
                    "certain lawsuits do not need to be tried with a jury for reasons such as " +
                    "protecting national secrets, and (iii) prohibiting specific judges from " +
                    "hearing cases for reasons such as the involvement of foreign factors in " +
                    "the case.",
            "The Committee for Safeguarding National Security of the Hong Kong " +
                    "Special Administrative Region shall have a National Security Adviser, who " +
                    "shall be designated by the ___ and provide advice on matters relating to " +
                    "the duties and functions of the Committee. The National Security Adviser " +
                    "shall sit in on meetings of the Committee.",
            "What are the possible consequences if one is charged with violating the " +
                    "Hong Kong national security law?",
            "The Hong Kong Special Administrative Region shall promote national " +
                    "security education in ___ and other means to raise the awareness of Hong " +
                    "Kong residents of national security and of the obligation to abide by the " +
                    "law.",
            "According to Article 3 of the National Security Law of the Hong Kong " +
                    "District, the ___ of the Region shall effectively prevent, suppress and " +
                    "impose punishment for any act or activity endangering national security in " +
                    "accordance with this Law and other relevant laws.",
            "The Chief Executive of the Hong Kong Special Administrative Region shall " +
                    "be accountable to the ___ for affairs relating to safeguarding national " +
                    "security in the Hong Kong Special Administrative Region and shall submit " +
                    "an annual report on the performance of duties of the Region in " +
                    "safeguarding national security.",
            "According to the Hong Kong National Security Law, which group has the " +
                    "obligation to maintain national sovereignty, unity, and territorial integrity?",
            "The Chief Executive shall designate a number of judges from the " +
                    "magistrates, the judges of the District Court, the judges of the Court of " +
                    "First Instance and the Court of Appeal of the High Court, and the judges of " +
                    "the Court of Final Appeal and may also designate a number of judges " +
                    "from deputy judges or recorders, to handle cases concerning offence " +
                    "endangering national security. Before making such designation, the Chief " +
                    "Executive may consult the Committee for Safeguarding National Security " +
                    "of the Hong Kong Special Administrative Region and the Chief Justice of " +
                    "the Court of Final Appeal. The term of office of the aforementioned " +
                    "designated judges shall be ___",
            "According to Article 19 of the Hong Kong Special Administrative Region " +
                    "National Security Law of the People's Republic of China, to which agency " +
                    "must the Financial Secretary of the Hong Kong Special Administrative " +
                    "a" +
                    "Region government submit a report each year on the control and " +
                    "management of funds related to national security expenditures?",
            "What are the circumstances under which the person who committed the " +
                    "crime can receive a lighter or reduced punishment, or even be exempt " +
                    "from punishment? These circumstances include: (i) not being a leader in " +
                    "the commission of the crime, (ii) voluntarily surrendering and truthfully " +
                    "confessing to the crime, and (iii) exposing the criminal behavior of others, " +
                    "verifying its authenticity, or providing important clues to solve other cases.",
            "The operation of an incorporated or unincorporated body such as a " +
                    "company or an organization shall be ___ if the body has been punished for " +
                    "committing an offence under this Law.",
            "In the course of performing duty, a holder of an identification document or " +
                    "a document of certification issued by the Office and the <National Security " +
                    "Law> Articles including vehicles used by the holder ___ subject to " +
                    "inspection, search or detention by law enforcement officers of the Region.",
            "The power of interpretation of this Law shall be vested in the Standing a" +
                    "Committee of the National People's Congress.",
            "Which of the following is a traditional national security field?",
            "The executive authorities, legislature and judiciary of the Region shall " +
                    "effectively ___ for any act or activity endangering national security in " +
                    "accordance with this Law and other relevant laws.",
            "In 2022, which two articles of the Law of the People's Republic of China " +
                    "on Safeguarding National Security in the Hong Kong Special " +
                    "Administrative Region did the Standing Committee of the 13th National " +
                    "People's Congress interpret?",
            "No __ shall be granted to a criminal suspect or defendant unless the ___ " +
                    "has sufficient grounds for believing that the criminal suspect or defendant " +
                    "will not continue to commit acts endangering national security."
    };
    public static final String[] OPTIONA = new String[]{
            "Responsible for reporting cases",
            "Basic terms",
            "11:00 a.m.",
            "Legislative Councilor",
            "One",
            "National People's Representative Meeting",
            "(i), (ii)",
            "Chief Executive",
            "national sovereignty",
            "Forbidden to listen in the press",
            "National Security Council",
            "When you are elected public office",
            "Approved by the Hong Kong Government or the State Security Office of " +
                    "Hong Kong",
            "Safeguarding national security",
            "The People's Republic of China Hong Kong Special Administrative " +
                    "Region Maintenance National Security Law",
            "(i)",
            "fight on local laws in Hong Kong",
            "Information sharing and operations coordination",
            "office for National matters",
            "Chief Executive",
            "Chief Executive",
            "Land safety",
            "(i) Political security",
            "national security",
            "(i), (ii)",
            "NPC Standing Committee",
            "(i), (ii), (iii)",
            "Resource safety",
            "Central People's Government",
            "I",
            "Guidance, supervision and" +
                    "supervision",
            "(i), (ii)",
            "State Council",
            "(i)",
            "party committee",
            "Funding from confiscated crimes",
            "Schools and through social groups, newspapers",
            "executive authorities, legislative agencies",
            "Central People's Government",
            "All Chinese people, including Hong Kong residents",
            "One year",
            "Legislative Council",
            "(i), (iii)",
            "Suspended or its license or business permit shall be revoked",
            "shall not be",
            "Standing Committee of the National People's Congress",
            "Economic security",
            "Prevent, suppress and impose punishment",
            "Article 13 and Article 46",
            "Bail, Police Office"
    };
    public static final String[] OPTIONB = new String[]{
            "Obliged to testify truthfully",
            "Fundamental provisions",
            "12:00 noon",
            "The Government",
            "Three",
            "State Council",
            "(ii), (iii)",
            "Secretary for Justice",
            "integrity and unity of the national territory",
            "Closed to the media and the public",
            "Committee for Safeguarding National Security",
            "When taking the civil service examination",
            "Approved by the Central Committee based on the report from the Hong " +
                    "Kong, Special Administrative Region in maintaining national security.",
            "National Security Law",
            "National Security Law of the Hong Kong Special Administrative Region " +
                    "a" +
                    "of the People's Republic of China.",
            "(i), (ii)",
            "based on national laws X",
            "Data and information sharing",
            "office for National Security Council",
            "State Council",
            "State Council",
            "Political security",
            "(i), (ii)",
            "the rule of law",
            "(i), (iii)",
            "Central People's Government",
            "(ii), (iii), (iv)",
            "Financial security",
            "National People's Congress",
            "II",
            "Promotion, advertising, and guidance",
            "(i), (ii), (iii)",
            "Central People's Government",
            "(i), (ii)",
            "President of the country",
            "Deported",
            "Schools, social organizations and through newspapers, magazines",
            "executive authorities, legislature and judiciary",
            "Legislative Council of the Hong Kong Special Administrative Region",
            "All Chinese people, excluding Hong Kong residents.",
            "Two years",
            "Executive Council",
            "(i), (ii)",
            "Revocation of its license or business permit",
            "shall be",
            "National People's Congress",
            "Cultural safety",
            "Resolve and Punish",
            "Article 14 and Article 47",
            "End of detention, HKSARG"
    };
    public static final String[] OPTIONC = new String[]{
            "Obliged to provide funding",
            "Important Terms and Conditions",
            "06:00 p.m.",
            "Relevant provisions of the laws in force",
            "Two people",
            "Final Court of Appeal",
            "(i), (ii), (iii)",
            "National People's Congress",
            "national sovereignty and unity",
            "Prohibit everyone from eavesdropping",
            "National Security Organization",
            "When elected or applying for a public position",
            "Approved by the Chief Executive and the Hong Kong Court of Final " +
                    "Appeal and reported to the Central Government.",
            "Legislation on Associations",
            "National Security Law of the Hong Kong Special Administrative Region " +
                    "of the People's Republic of China.",
            "(ii), (iii)",
            "prevail",
            "Resource and financial coordination",
            "office for safeguarding national security",
            "Special Administrative Region Government",
            "Special Administrative Region Government",
            "Resource security",
            "(i), (ii), (iii)",
            "presumption of innocence principle",
            "(ii), (iii)",
            "Office for safeguarding national security",
            "(i), (iii), (iv)",
            "Cultural safety",
            "National Committee of the Chinese People's Political Consultative" +
                    "Conference",
            "III",
            "Public communication, guidance," +
                    "supervision and regulation",
            "(i), (ii), (iii), (iv)",
            "Commissioner of Police",
            "(ii), (iii)",
            "Central People's Government",
            "Loss of the right to vote in" +
                    "constituency elections.",
            "Schools, social organizations and through newspapers, and the internet",
            "administrative agencies, judicial agencies",
            "National Committee of the Chinese People's Political Consultative " +
                    "Conference",
            "Hong Kong residents",
            "Three years",
            "Hong Kong Special Administrative Region Safeguarding National " +
                    "Security Committee",
            "(ii), (iii)",
            "Cease operation",
            "may not be",
            "State Council",
            "Ecological security",
            "Prevent and punish",
            "Article 15 and Article 48",
            "Bail, Judge"
    };
    public static final String[] OPTIOND = new String[]{
            "Obliged to stay in port temporarily",
            "Supreme Clause",
            "11:00 p.m.",
            "Internal Guidelines of the Government",
            "Five",
            "Standing Committee of the National People's Congress",
            "(ii)",
            "Committee for Safeguarding National Security",
            "sovereignty, unification and territorial integrity",
            "No family members or members of the public are allowed to attend",
            "National Security Office maintenance",
            "When running for or taking public office",
            "Transferred from the Hong Kong Police Force to the Hong Kong " +
                    "Garrison of the National Security Office.",
            "23 pieces of legislation",
            "Maintaining National Security Law in Hong Kong, China",
            "(i), (ii), (iii)",
            "subject to the final judgment of the Court of Final Appeal",
            "Personnel and resource coordination",
            "officer for National Security Research",
            "Central People's Government",
            "Central People's Government",
            "Military security",
            "(i), (ii), (iii), (iv)",
            "not being tried or punished again for" +
                    "the same crime",
            "(i), (ii), (iii)",
            "Central Liaison Office",
            "(i), (ii), (iii), (iv)",
            "Political security",
            "Executive Council of the Hong Kong Special Administrative Region",
            "IV",
            "Guidance, supervision, and" +
                    "management",
            "(ii), (iii), (iv)",
            "Chief Executive",
            "(i), (ii), (iii)",
            "National People's Congress",
            "Disqualification as a member of the Election Committee for the Chief" +
                    "Executive Election",
            "schools and universities and through social organisations, the media, " +
                    "the internet",
            "administrative agencies, legislative bodies, judicial bodies, national " +
                    "security agencies",
            "Final Court of Appeal",
            "Holders of Hong Kong Special Administrative Region Identity Cards",
            "Four years",
            "Office for Safeguarding National Security of the Central People's " +
                    "Government in the Hong Kong Special Administrative Region",
            "(i), (ii), (iii)",
            "Freeze all funds",
            "could be",
            "Final Court of Appeal",
            "None of the above.",
            "Prevent and alert",
            "Article 16 and Article 49",
            "End of detention, Judge"
    };
    public static final String[] RIGHTOPTION = new String[]{
            "B",
            "B",
            "D",
            "C",
            "B",
            "D",
            "D",
            "D",
            "D",
            "B",
            "B",
            "D",
            "A",
            "A",
            "A",
            "D",
            "C",
            "A",
            "C",
            "D",
            "D",
            "C",
            "A",
            "B",
            "A",
            "C",
            "D",
            "D",
            "A",
            "C",
            "C",
            "C",
            "D",
            "B",
            "C",
            "C",
            "D",
            "B",
            "A",
            "A",
            "A",
            "A",
            "C",
            "A",
            "A",
            "A",
            "D",
            "A",
            "B",
            "C"
    };
    public static final int[] RIGHTOPTIONNUM = new int[]{
            2,
            2,
            4,
            3,
            2,
            4,
            4,
            4,
            4,
            2,
            2,
            4,
            1,
            1,
            1,
            4,
            3,
            1,
            3,
            4,
            4,
            3,
            1,
            2,
            1,
            3,
            4,
            4,
            1,
            3,
            3,
            3,
            4,
            2,
            3,
            3,
            4,
            2,
            1,
            1,
            1,
            1,
            3,
            1,
            1,
            1,
            4,
            1,
            2,
            3
    };
}
