package ict.thei.lawtest.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtil {

    public static Date getTimestampByTimeString(String time) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm");
        Date date = null;
        try {
            date = simpleDateFormat.parse(time);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
        return date;
    }

    public static String getGenericCurrentTime() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm");
        Date date = null;
        date = Calendar.getInstance().getTime();
        String timeStr = simpleDateFormat.format(date);
        return timeStr;
    }

    //php与java转换末尾加000
    public static String getFormatTime(long time) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        String timeStr = simpleDateFormat.format(time * 1000);
        return timeStr;
    }

    public static String getFormatTimeExceptHourAndSecond(long time) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String timeStr = simpleDateFormat.format(time);
        return timeStr;
    }

    public static String getFormatShortTime(long time) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM-dd HH:mm");
        String timeStr = simpleDateFormat.format(time);
        return timeStr;
    }
    public static String getYearTime(long time) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy");
        String timeStr = simpleDateFormat.format(time);
        return timeStr;
    }

    public static String getFormatTimeByYear(long time) {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy");
        int timeYear = new Integer(simpleDateFormat.format(time));
        String timeStr = "";
        if (year == timeYear) {
            SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("MM-dd HH:mm");
            timeStr = simpleDateFormat2.format(time);
        } else {
            SimpleDateFormat simpleDateFormat3 = new SimpleDateFormat("yyyy-MM-dd");
            timeStr = simpleDateFormat3.format(time);
        }
        return timeStr;
    }

    public static String getFormatTimeToSecond(long time) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String timeStr = simpleDateFormat.format(time);
        return timeStr;
    }

    public static long getCurrentTime() {
        return Calendar.getInstance().getTimeInMillis();
    }
//
//	public static String getFormatTimeByWord(MCResource resource, long time, String pattern) {
//		String timeStr = null;
//		Date createdAt = new Date(time);
//		long l = new Date().getTime() - createdAt.getTime();
//		long day = l / (24 * 60 * 60 * 1000);
//		long hour = (l / (60 * 60 * 1000) - day * 24);
//		long min = ((l / (60 * 1000)) - day * 24 * 60 - hour * 60);
//		long s = (l / 1000 - day * 24 * 60 * 60 - hour * 60 * 60 - min * 60);
//		if (day > 0) {
////			DateFormat format = new SimpleDateFormat(pattern);
////			timeStr = format.format(createdAt);
//			SimpleDateFormat simpleDateFormat3 = new SimpleDateFormat("yyyy-MM-dd");
//			timeStr = simpleDateFormat3.format(time);
//		} else {
//			if (hour > 0) {
//				timeStr = hour + resource.getString("mc_forum_hour_before");
//			} else if (min > 0) {
//				timeStr = min + resource.getString("mc_forum_minute_before");
//			} else {
//				if (s < 0) {
//					SimpleDateFormat format = new SimpleDateFormat(pattern);
//					timeStr = format.format(createdAt);
//				} else {
//					timeStr = s + resource.getString("mc_forum_mill_before");
//				}
//			}
//		}
//		return timeStr;
//	}

    public static String getFormatTimeByPM(long time) {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH) + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        SimpleDateFormat simpleYear = new SimpleDateFormat("yyyy");
        SimpleDateFormat simpleMonth = new SimpleDateFormat("MM");
        SimpleDateFormat simpleDay = new SimpleDateFormat("dd");
        int timeYear = new Integer(simpleYear.format(time));
        int timeMonth = new Integer(simpleMonth.format(time));
        int timeDay = new Integer(simpleDay.format(time));
        String timeStr = "";
        if (year > timeYear) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd ahh:mm");
            timeStr = simpleDateFormat.format(time);
        } else {
            if (month == timeMonth && day == timeDay) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("ahh:mm");
                timeStr = simpleDateFormat.format(time);
            } else {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM-dd ahh:mm");
                timeStr = simpleDateFormat.format(time);
            }
        }
        return timeStr;
    }

    public static  String getDay(String day){
        String week = "";
        switch (day) {
            case "Monday":
                week = "星期一";
                break;
            case "Tuesday":
                week = "星期二";
                break;
            case "Wednesday":
                week = "星期三";
                break;
            case "Thursday":
                week = "星期四";
                break;
            case "Friday":
                week = "星期五";
                break;
            case "Saturday":
                week = "星期六";
                break;
            case "Sunday":
                week = "星期日";
                break;
        }
        return week;
    }
}
