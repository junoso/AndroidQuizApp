package ict.thei.lawtest.app;

import android.app.Application;
import android.content.Context;

import org.litepal.LitePal;


/* loaded from: classes4.dex */
public class BaseApplication extends Application {
    private static Context context;
    private static BaseApplication instance;


    public static Context getContext() {
        return context;
    }

    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        instance = this;
        context = getApplicationContext();
        //初始化吐司框架
        LitePal.initialize(this);
    }

    public static BaseApplication getInstance() {
        return instance;
    }
}