package ict.thei.lawtest.Data;

import org.litepal.crud.LitePalSupport;

public class LitePalBean extends LitePalSupport {
    public int id;
    public int score;//分数
    public String time;

    public LitePalBean(int score, String time) {
        this.score = score;
        this.time = time;
    }
}
