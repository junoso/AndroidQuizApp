package ict.thei.lawtest;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 3;
    private static final String DATABASE_NAME = "qa_database.db";
    private static final String TABLE_NAME = "qa_table";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_QUESTION = "question";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_QUESTION + " TEXT," +
                "option_a TEXT," +
                "option_b TEXT," +
                "option_c TEXT," +
                "option_d TEXT," +
                "correct_answer TEXT" +
                ")";
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void addQA(String question, String optionA, String optionB, String optionC, String optionD, String correctAnswer) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_QUESTION, question);
        values.put("option_a", optionA);
        values.put("option_b", optionB);
        values.put("option_c", optionC);
        values.put("option_d", optionD);
        values.put("correct_answer", correctAnswer);
        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    public Cursor getAllQA() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }

    public void deleteQA(String question) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, COLUMN_QUESTION + "=?", new String[]{question});
        db.close();
    }


}
