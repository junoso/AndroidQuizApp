package ict.thei.lawtest;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseIntArray;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import ict.thei.lawtest.Data.DataContent;
import ict.thei.lawtest.base.BaseRecyclerAdapter;
import ict.thei.lawtest.base.RecyclerViewHolder;

public class QuizActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private RecyclerView recyclerView;
    private QuizAdapter quizAdapter;
    private List<QAItem> qaList;
    private Button buttonSubmit, buttonBack;
    List<DataBean> dataBeans = new ArrayList<>();//一共50条数据
    List<DataBean> dataBeans2 = new ArrayList<>();//显示前20条数据

    private BaseRecyclerAdapter<DataBean> mAdapter1;

    private int rightNum = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quiz_activity);

        dbHelper = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.recyclerViewQuiz);
        buttonSubmit = findViewById(R.id.buttonSubmit);
        buttonBack = findViewById(R.id.btn_Back);

        qaList = new ArrayList<>();
        quizAdapter = new QuizAdapter(qaList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(quizAdapter);

        loadQAData();

        buttonSubmit.setOnClickListener(v -> submitAnswers());
        buttonBack.setOnClickListener(v -> {
            Intent intent = new Intent(QuizActivity.this, MainActivity.class);
            startActivity(intent);
        });
        recyclerView1();
        addData();
    }

    private void addData() {
        for (int i = 0; i < 50; i++) {
            DataBean dataBean = new DataBean();
            dataBean.question = DataContent.QUESTION[i];
            dataBean.optionA = DataContent.OPTIONA[i];
            dataBean.optionB = DataContent.OPTIONB[i];
            dataBean.optionC = DataContent.OPTIONC[i];
            dataBean.optionD = DataContent.OPTIOND[i];
            dataBean.rightOptionNum = DataContent.RIGHTOPTIONNUM[i];
            dataBean.rightOption = DataContent.RIGHTOPTION[i];
            dataBeans.add(dataBean);
        }
        Collections.shuffle(dataBeans); // 打乱数组顺序

        for (int i = 0; i < dataBeans.size(); i++) {
            if (i <= 19) {
                dataBeans2.add(dataBeans.get(i));
            } else {
                break;
            }
        }
        mAdapter1.setData(dataBeans2);
    }

    public int mSelectedItem = -1;

    private void recyclerView1() {
        recyclerView.setLayoutManager(new LinearLayoutManager(getBaseContext()));
        BaseRecyclerAdapter<DataBean> baseRecyclerAdapter = new BaseRecyclerAdapter<DataBean>(this, null) { // from class: soft.wl.textureviewcamera.MainActivity.6
            @Override // soft.wl.textureviewcamera.base.BaseRecyclerAdapter
            public int getItemLayoutId(int viewType) {
                return R.layout.item_quiz;//
            }

            @Override // soft.wl.textureviewcamera.base.BaseRecyclerAdapter
            public void bindData(RecyclerViewHolder holder, int position, DataBean item) {
                int No = position + 1;
                holder.getTextView(R.id.textQuestion).setText(No + "." + item.question);
                holder.getRadioButton(R.id.radioA).setText("A." + item.optionA);//序号
                holder.getRadioButton(R.id.radioB).setText("B." + item.optionB);//序号
                holder.getRadioButton(R.id.radioC).setText("C." + item.optionC);//序号
                holder.getRadioButton(R.id.radioD).setText("D." + item.optionD);//序号
                holder.getRadioButton(R.id.radioA).setOnCheckedChangeListener((buttonView, isChecked) -> {
                    if (!holder.getRadioButton(R.id.radioA).isPressed()) {
                        return;
                    }
                    if (isChecked) {
                        sia.append(holder.getAdapterPosition(), 1);
                        Log.e("zxd", "断点：" + sia);
                    }
                });
                holder.getRadioButton(R.id.radioB).setOnCheckedChangeListener((buttonView, isChecked) -> {
                    if (!holder.getRadioButton(R.id.radioB).isPressed()) {
                        return;
                    }
                    if (isChecked) {
                        sia.append(holder.getAdapterPosition(), 2);
                        Log.e("zxd", "断点：" + sia);
                    }
                });
                holder.getRadioButton(R.id.radioC).setOnCheckedChangeListener((buttonView, isChecked) -> {
                    if (!holder.getRadioButton(R.id.radioC).isPressed()) {
                        return;
                    }
                    if (isChecked) {
                        sia.append(holder.getAdapterPosition(), 3);
                        Log.e("zxd", "断点：" + sia);
                    }

                });
                holder.getRadioButton(R.id.radioD).setOnCheckedChangeListener((buttonView, isChecked) -> {
                    if (!holder.getRadioButton(R.id.radioD).isPressed()) {
                        return;
                    }
                    if (isChecked) {
                        sia.append(holder.getAdapterPosition(), 4);
                        Log.e("zxd", "断点：" + sia);
                    }
                });

                int i = sia.get(holder.getAdapterPosition(), -1);
                switch (i) {
                    case 1:
                        holder.getRadioButton(R.id.radioA).setChecked(true);
                        break;
                    case 2:
                        holder.getRadioButton(R.id.radioB).setChecked(true);
                        break;
                    case 3:
                        holder.getRadioButton(R.id.radioC).setChecked(true);
                        break;
                    case 4:
                        holder.getRadioButton(R.id.radioD).setChecked(true);
                        break;
                    case -1:
                        holder.getRadioGroup(R.id.radioGroup).clearCheck();
                        break;
                    default:
                        break;
                }
            }
        };
        mAdapter1 = baseRecyclerAdapter;
        recyclerView.setAdapter(baseRecyclerAdapter);
    }

    private void loadQAData() {
        Cursor cursor = dbHelper.getAllQA();
        if (cursor.moveToFirst()) {
            do {
                String question = cursor.getString(cursor.getColumnIndex("question"));
                String optionA = cursor.getString(cursor.getColumnIndex("option_a"));
                String optionB = cursor.getString(cursor.getColumnIndex("option_b"));
                String optionC = cursor.getString(cursor.getColumnIndex("option_c"));
                String optionD = cursor.getString(cursor.getColumnIndex("option_d"));
                String correctAnswer = cursor.getString(cursor.getColumnIndex("correct_answer"));

                QAItem qaItem = new QAItem(question, optionA, optionB, optionC, optionD, correctAnswer);
                qaList.add(qaItem);
            } while (cursor.moveToNext());
        }
        cursor.close();

        quizAdapter.notifyDataSetChanged();
    }

    private void submitAnswers() {
        SparseIntArray sia = BaseRecyclerAdapter.getSia();
        if (sia.size() < 20) {
            Toast.makeText(this, "Please complete all questions", Toast.LENGTH_SHORT).show();
//            ToastUtils.showLong("请完成所有题目");
            return;
        }
        if (sia.size() == dataBeans2.size()) {
            for (int i = 0; i < dataBeans2.size(); i++) {
                int key = sia.keyAt(i);
                int value = sia.get(key);
                if (dataBeans2.get(i).rightOptionNum == value) {
                    rightNum++;
                }
            }
            sia.clear();
            Intent intent = new Intent(this, ResultActivity.class);
            intent.putExtra("score", rightNum);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Please complete all questions", Toast.LENGTH_SHORT).show();
        }
    }
}