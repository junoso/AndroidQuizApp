package ict.thei.lawtest;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import ict.thei.lawtest.Data.LitePalBean;
import ict.thei.lawtest.utils.DateUtil;

public class ResultActivity extends AppCompatActivity {

    private AppCompatImageView mTvBack;
    private AppCompatImageView mImg;
    private TextView mTvScore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_result);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        initView();
        int score = getIntent().getIntExtra("score", 0);

        if (score >= 10) {
            mImg.setImageResource(R.mipmap.happy_face);
            mTvScore.setText("score：" + score + "/20 \nCongratulations on your,passing the test");
        } else {
            mTvScore.setText("score：" + score + "/20 \nsorry,failed to pass the exam");
            mImg.setImageResource(R.mipmap.cry_face);
        }
        LitePalBean litePalBean = new LitePalBean(score, DateUtil.getFormatTimeToSecond(DateUtil.getCurrentTime()));
        litePalBean.save();
    }

    private void initView() {
        mTvBack = findViewById(R.id.tvBack);
        mTvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        mImg = findViewById(R.id.img);
        mTvScore = findViewById(R.id.tvScore);
    }
}