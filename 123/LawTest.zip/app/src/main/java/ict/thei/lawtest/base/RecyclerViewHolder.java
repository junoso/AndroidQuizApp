package ict.thei.lawtest.base;

import android.content.Context;
import android.util.SparseArray;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.recyclerview.widget.RecyclerView;

/* loaded from: classes7.dex */
public class RecyclerViewHolder extends RecyclerView.ViewHolder {
    private View mConvertView;
    private SparseArray<View> mViews;

    public RecyclerViewHolder(Context ctx, View itemView) {
        super(itemView);
        this.mViews = new SparseArray<>();
        this.mConvertView = itemView;
    }

    private <T extends View> T findViewById(int viewId) {
        T t = (T) this.mViews.get(viewId);
        if (t == null) {
            View view = this.itemView.findViewById(viewId);
            T t2 = (T) view;
            this.mViews.put(viewId, t2);
            return t2;
        }
        return t;
    }

    public View getView(int viewId) {
        return findViewById(viewId);
    }

    public <T extends View> T getView2(int viewId) {
        T t = (T) this.mViews.get(viewId);
        if (t == null) {
            View view = this.mConvertView.findViewById(viewId);
            T t2 = (T) view;
            this.mViews.put(viewId, t2);
            return t2;
        }
        return t;
    }

    public TextView getTextView(int viewId) {
        return (TextView) getView(viewId);
    }

    public RecyclerView getRecyclerView(int viewId) {
        return (RecyclerView) getView(viewId);
    }

    public CheckBox getCheckBoxView(int viewId) {
        return (CheckBox) findViewById(viewId);
    }

    public Button getButton(int viewId) {
        return (Button) getView(viewId);
    }
    public RadioButton getRadioButton(int viewId) {
        return (RadioButton) getView(viewId);
    }
    public RadioGroup getRadioGroup(int viewId) {
        return (RadioGroup) getView(viewId);
    }

    public ImageView getImageView(int viewId) {
        return (ImageView) getView(viewId);
    }

    public VideoView getVideoView(int viewId) {
        return (VideoView) getView(viewId);
    }

    public ImageButton getImageButton(int viewId) {
        return (ImageButton) getView(viewId);
    }

    public EditText getEditText(int viewId) {
        return (EditText) getView(viewId);
    }

    public RecyclerViewHolder setText(int viewId, String value) {
        TextView view = (TextView) findViewById(viewId);
        view.setText(value);
        return this;
    }

    public RecyclerViewHolder setBackground(int viewId, int resId) {
        View view = findViewById(viewId);
        view.setBackgroundResource(resId);
        return this;
    }

    public RecyclerViewHolder setClickListener(int viewId, View.OnClickListener listener) {
        View view = findViewById(viewId);
        view.setOnClickListener(listener);
        return this;
    }
}