package ict.thei.lawtest;

import android.util.SparseIntArray;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import org.jetbrains.annotations.NotNull;

public class DataBean {

    public String question;//题目
    public String optionA;//答案A
    public String optionB;
    public String optionC;
    public String optionD;
    public String rightOption;//正确答案
    public int rightOptionNum;//正确答案
    public String selOption;

}
