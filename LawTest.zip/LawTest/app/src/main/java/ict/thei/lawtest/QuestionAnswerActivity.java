package ict.thei.lawtest;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class QuestionAnswerActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private int category;
    private int currentQuestionIndex = 0;
    private Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_question);


        dbHelper = new DatabaseHelper(this);

        category = getIntent().getIntExtra("CATEGORY", 1);

        loadQuestions();
    }

    private void loadQuestions() {
        cursor = dbHelper.getQuestionsByCategory(category);
        if (cursor.moveToFirst()) {
            displayCurrentQuestion();
        } else {
            Toast.makeText(this, "No questions available.", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayCurrentQuestion() {
        if (cursor.moveToPosition(currentQuestionIndex)) {
            String question = cursor.getString(cursor.getColumnIndex("question"));
            String optionA = cursor.getString(cursor.getColumnIndex("option_a"));
            String optionB = cursor.getString(cursor.getColumnIndex("option_b"));
            String optionC = cursor.getString(cursor.getColumnIndex("option_c"));
            String optionD = cursor.getString(cursor.getColumnIndex("option_d"));


        }
    }

}