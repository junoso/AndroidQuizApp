package ict.thei.lawtest;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.CountDownTimer;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class QuizActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private RecyclerView recyclerView;
    private QuizAdapter quizAdapter;
    private List<QAItem> qaList;
    private Button buttonSubmit, buttonBack;
    private TextView timerTextView;
    private CountDownTimer countDownTimer;
    private static final long START_TIME_IN_MILLIS = 10000; // 10 seconds
    private boolean timerRunning = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quiz_activity);

        dbHelper = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.recyclerViewQuiz);
        buttonSubmit = findViewById(R.id.buttonSubmit);
        buttonBack = findViewById(R.id.btn_Back);
        timerTextView = findViewById(R.id.timerTextView);

        qaList = new ArrayList<>();
        quizAdapter = new QuizAdapter(qaList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(quizAdapter);

        startTimer();
        loadQAData();

        buttonSubmit.setOnClickListener(v -> submitAnswers());
        buttonBack.setOnClickListener(v -> {
            Intent intent = new Intent(QuizActivity.this, MainActivity.class);
            startActivity(intent);
        });
    }

    private void loadQAData() {
        Cursor cursor = dbHelper.getAllQA();
        if (cursor.moveToFirst()) {
            do {
                String question = cursor.getString(cursor.getColumnIndex("question"));
                String optionA = cursor.getString(cursor.getColumnIndex("option_a"));
                String optionB = cursor.getString(cursor.getColumnIndex("option_b"));
                String optionC = cursor.getString(cursor.getColumnIndex("option_c"));
                String optionD = cursor.getString(cursor.getColumnIndex("option_d"));
                String correctAnswer = cursor.getString(cursor.getColumnIndex("correct_answer"));
                int category = cursor.getInt(cursor.getColumnIndex("category"));
                QAItem qaItem = new QAItem(question, optionA, optionB, optionC, optionD, correctAnswer, category);
                qaList.add(qaItem);
            } while (cursor.moveToNext());
        }
        cursor.close();

        quizAdapter.notifyDataSetChanged();
    }

    private void submitAnswers() {
        int score = 0;
        HashMap<Integer, String> selectedAnswers = quizAdapter.getSelectedAnswers();

        for (int i = 0; i < qaList.size(); i++) {
            String selectedAnswer = selectedAnswers.get(i);
            if (selectedAnswer != null && selectedAnswer.trim().equals(qaList.get(i).getCorrectAnswer().trim())) {
                score++;
            } else {
                Log.d("QuizActivity", "Question " + i + ": Selected = " + selectedAnswer + ", Correct = " + qaList.get(i).getCorrectAnswer());
            }
        }
        Toast.makeText(this, "Your score: " + score + "/" + qaList.size(), Toast.LENGTH_SHORT).show();
    }

    private void startTimer() {
        countDownTimer = new CountDownTimer(START_TIME_IN_MILLIS, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                updateTimer(millisUntilFinished);
            }

            @Override
            public void onFinish() {
                timerRunning = false;
                timerTextView.setText("0:00");

                int score = calculateScore(quizAdapter.getSelectedAnswers());
                Intent intent = new Intent(QuizActivity.this, TimeOverActivity.class);
                intent.putExtra("SCORE", score);
                startActivity(intent);
                finish();
            }
        }.start();
    }

    private void updateTimer(long millisUntilFinished) {
        int seconds = (int) (millisUntilFinished / 1000);
        String timeLeftFormatted = String.format("%d:%02d", seconds / 60, seconds % 60);
        timerTextView.setText(timeLeftFormatted);
    }

    private int calculateScore(HashMap<Integer, String> selectedAnswers) {
        int score = 0;
        for (int i = 0; i < qaList.size(); i++) {
            String selectedAnswer = selectedAnswers.get(i);
            if (selectedAnswer != null && selectedAnswer.equals(qaList.get(i).getCorrectAnswer())) {
                score++;
            }
        }
        return score;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
    }
}