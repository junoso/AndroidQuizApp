package ict.thei.lawtest;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.HashMap;
import java.util.List;

public class QuizAdapter extends RecyclerView.Adapter<QuizAdapter.QuizViewHolder> {
    private List<QAItem> qaList;
    private HashMap<Integer, String> selectedAnswers = new HashMap<>();

    public QuizAdapter(List<QAItem> qaList) {
        this.qaList = qaList;
    }

    @NonNull
    @Override
    public QuizViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_quiz, parent, false);
        return new QuizViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull QuizViewHolder holder, int position) {
        QAItem qaItem = qaList.get(position);
        holder.questionTextView.setText(qaItem.getQuestion());

        // Clear previous selections
        holder.radioGroup.clearCheck();

        // Set options text
        holder.optionA.setText(qaItem.getOptionA());
        holder.optionB.setText(qaItem.getOptionB());
        holder.optionC.setText(qaItem.getOptionC());
        holder.optionD.setText(qaItem.getOptionD());

        // Set previously selected answer if it exists
        String selectedAnswer = selectedAnswers.get(position);
        if (selectedAnswer != null) {
            if (selectedAnswer.equals("A")) {
                holder.optionA.setChecked(true);
            } else if (selectedAnswer.equals("B")) {
                holder.optionB.setChecked(true);
            } else if (selectedAnswer.equals("C")) {
                holder.optionC.setChecked(true);
            } else if (selectedAnswer.equals("D")) {
                holder.optionD.setChecked(true);
            }
        }

        holder.radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            String answer = "";
            if (checkedId == R.id.radioA) {
                answer = "A";
            } else if (checkedId == R.id.radioB) {
                answer = "B";
            } else if (checkedId == R.id.radioC) {
                answer = "C";
            } else if (checkedId == R.id.radioD) {
                answer = "D";
            }
            selectedAnswers.put(position, answer);
        });
    }

    @Override
    public int getItemCount() {
        return qaList.size();
    }

    public HashMap<Integer, String> getSelectedAnswers() {
        return selectedAnswers;
    }

    static class QuizViewHolder extends RecyclerView.ViewHolder {
        TextView questionTextView;
        RadioGroup radioGroup;
        RadioButton optionA, optionB, optionC, optionD;

        public QuizViewHolder(View itemView) {
            super(itemView);
            questionTextView = itemView.findViewById(R.id.textQuestion);
            radioGroup = itemView.findViewById(R.id.radioGroup);
            optionA = itemView.findViewById(R.id.radioA);
            optionB = itemView.findViewById(R.id.radioB);
            optionC = itemView.findViewById(R.id.radioC);
            optionD = itemView.findViewById(R.id.radioD);
        }
    }
}