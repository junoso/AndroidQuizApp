package ict.thei.lawtest;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class AnswerQuestionAdapter extends RecyclerView.Adapter<AnswerQuestionAdapter.AnswerViewHolder> {
    private List<QAItem> qaList;

    public AnswerQuestionAdapter(List<QAItem> qaList) {
        this.qaList = qaList;
    }

    @NonNull
    @Override
    public AnswerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_question_answer, parent, false);
        return new AnswerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AnswerViewHolder holder, int position) {
        QAItem qaItem = qaList.get(position);
        holder.questionTextView.setText(qaItem.getQuestion());

        String correctAnswerText = "";
        switch (qaItem.getCorrectAnswer()) {
            case "A":
                correctAnswerText = qaItem.getOptionA();
                break;
            case "B":
                correctAnswerText = qaItem.getOptionB();
                break;
            case "C":
                correctAnswerText = qaItem.getOptionC();
                break;
            case "D":
                correctAnswerText = qaItem.getOptionD();
                break;
        }

        holder.answerTextView.setText(correctAnswerText);
    }

    @Override
    public int getItemCount() {
        return qaList.size();
    }

    static class AnswerViewHolder extends RecyclerView.ViewHolder {
        TextView questionTextView;
        TextView answerTextView;

        public AnswerViewHolder(View itemView) {
            super(itemView);
            questionTextView = itemView.findViewById(R.id.textQuestion);
            answerTextView = itemView.findViewById(R.id.textAnswer);
        }
    }
}