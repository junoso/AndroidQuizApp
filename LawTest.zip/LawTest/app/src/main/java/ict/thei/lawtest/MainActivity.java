package ict.thei.lawtest;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private String currentState = "home";
    private FrameLayout stateContainer;

    Button btnHome, btnData, btnLogin, btnQuit;

    EditText editTextConfirmPassword;

    private EditText editTextUsername, editTextPassword;
    private Button buttonLogin, buttonRegisterUser;

    private static final String ADMIN_USERNAME = "admin";
    private static final String ADMIN_PASSWORD = "admin123";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        stateContainer = findViewById(R.id.stateContainer);
        btnHome = findViewById(R.id.btn_Home);
        btnData = findViewById(R.id.btn_Data);
        btnLogin = findViewById(R.id.btn_Login);
        btnQuit = findViewById(R.id.btn_Quit);

        loadHomeState();

        btnHome.setOnClickListener(v -> switchState("home"));
        btnData.setOnClickListener(v -> switchState("data"));
        btnLogin.setOnClickListener(v -> {
            if (isUserLoggedIn()) {
                switchState("logout");
            } else {
                switchState("login");
            }
        });
        btnQuit.setOnClickListener(v -> finish());
    }

    private boolean isUserLoggedIn() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String loggedInUsername = sharedPreferences.getString("loggedInUsername", null);
        return loggedInUsername != null;
    }


    private void switchState(String state) {
        if (state.equals(currentState)) return;
        currentState = state;

        switch (state) {
            case "home":
                buttonGrey();
                btnHome.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#E76B5F")));
                loadHomeState();
                break;
            case "data":
                buttonGrey();
                btnData.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#E76B5F")));
                loadDataState();
                break;
            case "login":
                buttonGrey();
                btnLogin.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#E76B5F")));
                loadLoginState();
                break;
            case "logout":
                buttonGrey();
                btnLogin.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#E76B5F")));
                loadLogoutState();
                break;
            case "register":
                buttonGrey();
                btnLogin.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#E76B5F")));
                loadRegisterState();
                break;
            case "question":
                loadQuestion();
                buttonGrey();
                break;
            case "about":
                loadAboutState();
                buttonGrey();
                break;
            case "website":
                websiteState();
                buttonGrey();
                break;
        }
    }

    private void buttonGrey() {
        btnData.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#999999")));
        btnLogin.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#999999")));
        btnHome.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#999999")));
    }

    private void loadHomeState() {
        stateContainer.removeAllViews();
        View homeView = getLayoutInflater().inflate(R.layout.state_home, null);
        stateContainer.addView(homeView);
        Button btnTest = homeView.findViewById(R.id.btn_test);
        Button btnQuestion = homeView.findViewById(R.id.btn_question);
        Button btnWebsite = homeView.findViewById(R.id.btn_Websites);
        Button btnAbout = homeView.findViewById(R.id.btn_about);

        btnQuestion.setOnClickListener(v -> switchState("question"));
        btnWebsite.setOnClickListener(v -> switchState("website"));
        btnAbout.setOnClickListener(v -> switchState("about"));

        btnTest.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, StartQuestionActivity.class);
            startActivity(intent);
        });
    }

    private void loadDataState() {
        stateContainer.removeAllViews();
        View dataView = getLayoutInflater().inflate(R.layout.state_data, null);
        stateContainer.addView(dataView);
    }

    private void loadLoginState() {
        stateContainer.removeAllViews();
        View loginView = getLayoutInflater().inflate(R.layout.state_login, null);
        stateContainer.addView(loginView);
        editTextUsername = loginView.findViewById(R.id.editTextUsername);
        editTextPassword = loginView.findViewById(R.id.editTextPassword);
        buttonLogin = loginView.findViewById(R.id.buttonLogin);
        buttonRegisterUser = loginView.findViewById(R.id.buttonRegisterUser);

        buttonRegisterUser.setOnClickListener(v -> switchState("register"));
        buttonLogin.setOnClickListener(v -> login());
    }

    private void loadLogoutState() {
        stateContainer.removeAllViews();
        View logoutView = getLayoutInflater().inflate(R.layout.state_logout, null);
        stateContainer.addView(logoutView);

        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String username = sharedPreferences.getString("loggedInUsername", "User");

        TextView tvUsername = logoutView.findViewById(R.id.tv_username);
        tvUsername.setText("Account: " + username);

        Button buttonLogout = logoutView.findViewById(R.id.btn_Logout);
        Button buttonDeleteAccount = logoutView.findViewById(R.id.btn_DeleteAccount);
        Button buttonDeleteData = logoutView.findViewById(R.id.btn_DeleteData);

        buttonLogout.setOnClickListener(v -> loadConfirmtion(2));
        buttonDeleteAccount.setOnClickListener(v -> loadConfirmtion(3));
        buttonDeleteData.setOnClickListener(v -> loadConfirmtion(4));
    }

    private void loadConfirmtion(int question) {
        stateContainer.removeAllViews();
        View confirmView = getLayoutInflater().inflate(R.layout.state_confirm, null);
        stateContainer.addView(confirmView);
        TextView tvQuestion = confirmView.findViewById(R.id.tv_question);
        Button buttonYes = confirmView.findViewById(R.id.btn_yes);
        Button buttonNo = confirmView.findViewById(R.id.btn_no); // Corrected button ID

        if (question == 1){
            tvQuestion.setText("Do you need to update the answer data to your account?");
        } else if (question == 2){
            tvQuestion.setText("Would you like to log out?");
        } else if (question == 3){
            tvQuestion.setText("Would you like to delete the account?");
        } else if (question == 4){
            tvQuestion.setText("Would you like to delete data?");
        }

        buttonYes.setOnClickListener(v -> {
            if (question == 2) {
                logout();
            } else if (question == 3) {
                deleteAccount();
                Toast.makeText(this, "Your account has been deleted.", Toast.LENGTH_SHORT).show();
                switchState("home");
            } else if (question == 4) {
                // Handle data deletion logic here
                Toast.makeText(this, "Data deletion logic goes here", Toast.LENGTH_SHORT).show();
                switchState("logout");
            }
        });

        buttonNo.setOnClickListener(v -> switchState("home"));
    }

    private void loadRegisterState() {
        stateContainer.removeAllViews();
        View registerView = getLayoutInflater().inflate(R.layout.state_register, null);
        stateContainer.addView(registerView);

        editTextUsername = registerView.findViewById(R.id.editTextUsername);
        editTextPassword = registerView.findViewById(R.id.editTextPassword);
        editTextConfirmPassword = registerView.findViewById(R.id.editTextConfirmPassword);
        Button buttonRegister = registerView.findViewById(R.id.buttonRegister);

        buttonRegister.setOnClickListener(v -> registerUser());
    }

    private void loadAboutState() {
        stateContainer.removeAllViews();
        View aboutView = getLayoutInflater().inflate(R.layout.state_about, null);
        stateContainer.addView(aboutView);
    }

    private void loadQuestion() {
        stateContainer.removeAllViews();
        View questionView = getLayoutInflater().inflate(R.layout.state_question, null);
        stateContainer.addView(questionView);

        Button btnNSLQ = questionView.findViewById(R.id.btn_NSLQ);
        Button btnMQ = questionView.findViewById(R.id.btn_MQ);
        Button btnBLQ = questionView.findViewById(R.id.btn_BLQ);
        Button btnWQ = questionView.findViewById(R.id.btn_WQ);

        btnNSLQ.setOnClickListener(v -> startAnswerQuestionActivity("NSLQ"));
        btnMQ.setOnClickListener(v -> startAnswerQuestionActivity("MQ"));
        btnBLQ.setOnClickListener(v -> startAnswerQuestionActivity("BLQ"));
        btnWQ.setOnClickListener(v -> startAnswerQuestionActivity("WQ"));
    }

    private void startAnswerQuestionActivity(String selectedQuestionType) {
        Intent intent = new Intent(MainActivity.this, AnswerQuestion.class);
        intent.putExtra("selected_question_type", selectedQuestionType);
        startActivity(intent);
    }

    private void websiteState() {
        stateContainer.removeAllViews();
        View websiteView = getLayoutInflater().inflate(R.layout.state_law_website, null);
        stateContainer.addView(websiteView);
        Button btnBasicLaw = websiteView.findViewById(R.id.btn_basiclaw);
        Button btnNationalSecurity = websiteView.findViewById(R.id.btn_nationalsecurity);

        btnBasicLaw.setOnClickListener(v -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.basiclaw.gov.hk/en/basiclaw/index.html"));
            startActivity(browserIntent);
        });

        btnNationalSecurity.setOnClickListener(v -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.isd.gov.hk/nationalsecurity/eng/pdf/NSL_Booklet.pdf"));
            startActivity(browserIntent);
        });
    }

    private void login() {
        String username = editTextUsername.getText().toString();
        String password = editTextPassword.getText().toString();

        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String storedPassword = sharedPreferences.getString(username, null);

        if (username.equals(ADMIN_USERNAME) && password.equals(ADMIN_PASSWORD)) {
            Intent intent = new Intent(MainActivity.this, AddQuestion.class);
            startActivity(intent);
        } else if (storedPassword != null && storedPassword.equals(password)) {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("loggedInUsername", username);
            editor.apply();

            switchState("logout");
        } else {
            Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
        }
    }

    private void logout() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("loggedInUsername");
        editor.apply();

        switchState("home");
    }

    private void registerUser() {
        String username = editTextUsername.getText().toString();
        String password = editTextPassword.getText().toString();
        String confirmPassword = editTextConfirmPassword.getText().toString();

        if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "User registered successfully!", Toast.LENGTH_SHORT).show();

        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(username, password);
        editor.apply();

        switchState("login");
    }

    private void deleteAccount() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String loggedInUsername = sharedPreferences.getString("loggedInUsername", null);
        if (loggedInUsername != null) {
            editor.remove(loggedInUsername);
            editor.remove("loggedInUsername");
        }
        editor.apply();
    }

}