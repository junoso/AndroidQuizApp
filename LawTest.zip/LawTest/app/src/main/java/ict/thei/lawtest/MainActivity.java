package ict.thei.lawtest;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    private String currentState = "home";
    private FrameLayout stateContainer;

    Button btnHome, btnData, btnLogin, btnQuit;

    EditText editTextConfirmPassword;

    private EditText editTextUsername, editTextPassword;
    private Button buttonLogin, buttonRegisterUser;

    private static final String ADMIN_USERNAME = "admin";
    private static final String ADMIN_PASSWORD = "admin123";

    private static final String USER_USERNAME = "user";
    private static final String USER_PASSWORD = "user123";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        stateContainer = findViewById(R.id.stateContainer);
        loadHomeState();
        btnHome = findViewById(R.id.btn_Home);
        btnData = findViewById(R.id.btn_Data);
        btnLogin = findViewById(R.id.btn_Login);
        btnQuit = findViewById(R.id.btn_Quit);

        // Initialize state
        switchState("home");
        btnHome.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#E76B5F")));
        btnHome.setOnClickListener(v -> switchState("home"));
        btnData.setOnClickListener(v -> switchState("data"));
        btnLogin.setOnClickListener(v -> switchState("login"));
        btnQuit.setOnClickListener(v -> finish());
    }

    private void switchState(String state) {
        if (state.equals(currentState)) return;
        currentState = state;

        switch (state) {
            case "home":
                buttonGrey();
                btnHome.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#E76B5F")));
                loadHomeState();
                break;
            case "data":
                buttonGrey();
                btnData.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#E76B5F")));
                loadDataState();
                break;
            case "login":
                buttonGrey();
                btnLogin.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#E76B5F")));
                loadLoginState();
                break;
            case "logout":
                buttonGrey();
                btnLogin.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#E76B5F")));
                loadLogoutState();
                break;
            case "register":
                buttonGrey();
                btnLogin.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#E76B5F")));
                loadRegisterState();
                break;
            case "question":
                loadQuestion();
                buttonGrey();
                break;
            case "about":
                loadAboutState();
                buttonGrey();
                break;
            case "website":
                websiteState();
                buttonGrey();
                break;
        }
    }

    private void buttonGrey(){
        btnData.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#999999")));
        btnLogin.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#999999")));
        btnHome.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#999999")));
    }

    private void loadHomeState() {
        stateContainer.removeAllViews();
        View homeView = getLayoutInflater().inflate(R.layout.state_home, null);
        stateContainer.addView(homeView);
        Button btnTest = homeView.findViewById(R.id.btn_test);
        Button btnQuestion = homeView.findViewById(R.id.btn_question);
        Button btnWebsite = homeView.findViewById(R.id.btn_Websites);
        Button btnAabout = homeView.findViewById(R.id.btn_about);

        btnQuestion.setOnClickListener(v -> switchState("question"));
        btnWebsite.setOnClickListener(v -> switchState("website"));
        btnAabout.setOnClickListener(v -> switchState("about"));

        btnTest.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, QuizActivity.class);
            startActivity(intent);
        });
    }

    private void loadDataState() {
        stateContainer.removeAllViews();
        View dataView = getLayoutInflater().inflate(R.layout.state_data, null);
        stateContainer.addView(dataView);
    }

    private void loadLoginState() {
        stateContainer.removeAllViews();
        View dataView = getLayoutInflater().inflate(R.layout.state_login, null);
        stateContainer.addView(dataView);
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonRegisterUser = findViewById(R.id.buttonRegisterUser);

        buttonRegisterUser.setOnClickListener(v -> switchState("register"));
        buttonLogin.setOnClickListener(v -> login());
    }

    private void loadLogoutState() {
        stateContainer.removeAllViews();
        View dataView = getLayoutInflater().inflate(R.layout.state_logout, null);
        stateContainer.addView(dataView);

        Button buttonLogout = findViewById(R.id.btn_Logout);
        Button buttonDeleteAccount = findViewById(R.id.btn_DeleteAccount);
        Button buttonDeleteData = findViewById(R.id.btn_DeleteData);

        buttonLogout.setOnClickListener(v -> {loadConfirmtion(2);});
        buttonDeleteAccount.setOnClickListener(v -> {loadConfirmtion(3);});
        buttonDeleteData.setOnClickListener(v -> {loadConfirmtion(4);});
    }

    private void loadConfirmtion(int question) {
        stateContainer.removeAllViews();
        View aboutView = getLayoutInflater().inflate(R.layout.state_confirm, null);
        stateContainer.addView(aboutView);
        TextView tvQuestion = findViewById(R.id.tv_question);
        Button buttonYes = findViewById(R.id.btn_yes);
        Button buttonNo = findViewById(R.id.btn_yes);
        if (question == 1){
            tvQuestion.setText("Do you need to update the answer data to your account?");
        } else if (question == 2){
            tvQuestion.setText("Whether to log out?");
        } else if (question == 3){
            tvQuestion.setText("Whether to delete data?");
        } else if (question == 4){
            tvQuestion.setText("Whether to delete the account?");
        }

        buttonYes.setOnClickListener(v -> {
            if (question == 1){
                //...
                switchState("data");
            } else if (question == 2){
                //...
                switchState("login");
            } else if (question == 3){
                //...
                switchState("logout");
            } else if (question == 4){
                //...
                switchState("login");
            }
        });
        buttonNo.setOnClickListener(v -> {
            if (question == 1){
                //...
                switchState("data");
            } else if (question == 2){
                //...
                switchState("logout");
            } else if (question == 3){
                //...
                switchState("logout");
            } else if (question == 4){
                //...
                switchState("logout");
            }
        });
    }

    private void loadRegisterState() {
        stateContainer.removeAllViews();
        View dataView = getLayoutInflater().inflate(R.layout.state_register, null);
        stateContainer.addView(dataView);

        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextConfirmPassword = findViewById(R.id.editTextConfirmPassword);
        Button buttonRegister = findViewById(R.id.buttonRegister);

        buttonRegister.setOnClickListener(v -> registerUser());
    }

    private void loadAboutState() {
        stateContainer.removeAllViews();
        View aboutView = getLayoutInflater().inflate(R.layout.state_about, null);
        stateContainer.addView(aboutView);
    }

    private void loadQuestion() {
        stateContainer.removeAllViews();
        View aboutView = getLayoutInflater().inflate(R.layout.state_question, null);
        stateContainer.addView(aboutView);
    }

    private void websiteState() {
        stateContainer.removeAllViews();
        View websiteView = getLayoutInflater().inflate(R.layout.state_law_website, null);
        stateContainer.addView(websiteView);
        Button btnBasicLaw = websiteView.findViewById(R.id.btn_basiclaw);
        Button btnNationalSecurity = websiteView.findViewById(R.id.btn_nationalsecurity);

        btnBasicLaw.setOnClickListener(v -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.basiclaw.gov.hk/en/basiclaw/index.html"));
            startActivity(browserIntent);
        });

        btnNationalSecurity.setOnClickListener(v -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.isd.gov.hk/nationalsecurity/eng/pdf/NSL_Booklet.pdf"));
            startActivity(browserIntent);
        });
    }

    private void login() {
        String username = editTextUsername.getText().toString();
        String password = editTextPassword.getText().toString();

        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String storedPassword = sharedPreferences.getString(username, null);

        if (username.equals(ADMIN_USERNAME) && password.equals(ADMIN_PASSWORD)) {
            Intent intent = new Intent(MainActivity.this, AddQuestion.class);
            startActivity(intent);
        } else if (storedPassword != null && storedPassword.equals(password)) {
            switchState("home");
        } else {
            Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
        }
        //如果有答題幾紀錄且未登入 loadConfirmtion(1);
    }

    private void registerUser() {
        String username = editTextUsername.getText().toString();
        String password = editTextPassword.getText().toString();
        String confirmPassword = editTextConfirmPassword.getText().toString();

        if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "User registered successfully!", Toast.LENGTH_SHORT).show();

        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(username, password);
        editor.apply();

        switchState("login");
    }

}