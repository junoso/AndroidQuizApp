package ict.thei.lawtest;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class AnswerQuestion extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private RecyclerView recyclerView;
    private List<QAItem> qaList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.state_question);

        dbHelper = new DatabaseHelper(this);
        Button btnBLQ = findViewById(R.id.btn_BLQ);
        Button btnNSLQ = findViewById(R.id.btn_NSLQ);

        btnBLQ.setOnClickListener(v -> loadQuestions(1));
        btnNSLQ.setOnClickListener(v -> loadQuestions(2));

        String selectedQuestionType = getIntent().getStringExtra("selected_question_type");
        if (selectedQuestionType != null) {
            loadQuestions(selectedQuestionType);
        }
    }

    private void loadQuestions(int category) {
        qaList = new ArrayList<>();
        Cursor cursor = dbHelper.getQuestionsByCategory(category);

        if (cursor.moveToFirst()) {
            do {
                String question = cursor.getString(cursor.getColumnIndex("question"));
                String optionA = cursor.getString(cursor.getColumnIndex("option_a"));
                String optionB = cursor.getString(cursor.getColumnIndex("option_b"));
                String optionC = cursor.getString(cursor.getColumnIndex("option_c"));
                String optionD = cursor.getString(cursor.getColumnIndex("option_d"));
                String correctAnswer = cursor.getString(cursor.getColumnIndex("correct_answer"));
                int questionCategory = category;

                QAItem qaItem = new QAItem(question, optionA, optionB, optionC, optionD, correctAnswer, questionCategory);
                qaList.add(qaItem);
            } while (cursor.moveToNext());
        } else {
            Toast.makeText(this, "No questions available for this category.", Toast.LENGTH_SHORT).show();
        }
        cursor.close();

        if (recyclerView == null) {
            setContentView(R.layout.item_question);
            recyclerView = findViewById(R.id.recyclerView);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
        }

        AnswerQuestionAdapter answerQuestionAdapter = new AnswerQuestionAdapter(qaList);
        recyclerView.setAdapter(answerQuestionAdapter);
    }

    private void loadQuestions(String questionType) {
        int category = questionType.equals("BLQ") ? 1 : 2;
        loadQuestions(category);
    }
}