package ict.thei.lawtest;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class AddQuestion extends AppCompatActivity {
    DatabaseHelper dbHelper;
    EditText editTextQuestion;
    EditText editTextOptionA;
    EditText editTextOptionB;
    EditText editTextOptionC;
    EditText editTextOptionD;
    Button buttonAdd;
    Button buttonDelete;
    RecyclerView recyclerView;
    QAAdapter qaAdapter;
    List<QAItem> qaList;
    Spinner spinnerCorrectAnswer;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_question);

        dbHelper = new DatabaseHelper(this);
        editTextQuestion = findViewById(R.id.editTextQuestion);
        editTextOptionA = findViewById(R.id.editTextOptionA);
        editTextOptionB = findViewById(R.id.editTextOptionB);
        editTextOptionC = findViewById(R.id.editTextOptionC);
        editTextOptionD = findViewById(R.id.editTextOptionD);
        buttonAdd = findViewById(R.id.buttonAdd);
        buttonDelete = findViewById(R.id.buttonDelete);
        recyclerView = findViewById(R.id.recyclerView);

        spinnerCorrectAnswer = findViewById(R.id.spinnerCorrectAnswer);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.answer_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCorrectAnswer.setAdapter(adapter);

        qaList = new ArrayList<>();
        qaAdapter = new QAAdapter(qaList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(qaAdapter);

        buttonAdd.setOnClickListener(v -> {
            String question = editTextQuestion.getText().toString();
            String optionA = editTextOptionA.getText().toString();
            String optionB = editTextOptionB.getText().toString();
            String optionC = editTextOptionC.getText().toString();
            String optionD = editTextOptionD.getText().toString();
            String correctAnswer = spinnerCorrectAnswer.getSelectedItem().toString();

            if (!question.isEmpty() && !optionA.isEmpty() && !optionB.isEmpty() && !optionC.isEmpty() && !optionD.isEmpty()) {
                dbHelper.addQA(question, optionA, optionB, optionC, optionD, correctAnswer);
                loadQAData();
                clearInputFields();
            }
        });

        buttonDelete.setOnClickListener(v -> {
            int position = qaAdapter.getSelectedPosition();
            if (position != -1) {
                dbHelper.deleteQA(qaList.get(position).getQuestion());
                qaAdapter.deleteItem(position);
            }
        });

        loadQAData();
    }

    private void loadQAData() {
        qaList.clear();
        Cursor cursor = dbHelper.getAllQA();

        if (cursor.moveToFirst()) {
            do {
                String question = cursor.getString(cursor.getColumnIndex("question"));
                String optionA = cursor.getString(cursor.getColumnIndex("option_a"));
                String optionB = cursor.getString(cursor.getColumnIndex("option_b"));
                String optionC = cursor.getString(cursor.getColumnIndex("option_c"));
                String optionD = cursor.getString(cursor.getColumnIndex("option_d"));
                String correctAnswer = cursor.getString(cursor.getColumnIndex("correct_answer"));

                QAItem qaItem = new QAItem(question, optionA, optionB, optionC, optionD, correctAnswer);
                qaList.add(qaItem);
            } while (cursor.moveToNext());
        }
        cursor.close();

        qaAdapter.notifyDataSetChanged();
    }

    private void clearInputFields() {
        editTextQuestion.setText("");
        editTextOptionA.setText("");
        editTextOptionB.setText("");
        editTextOptionC.setText("");
        editTextOptionD.setText("");
        spinnerCorrectAnswer.setSelection(0);
    }
}
