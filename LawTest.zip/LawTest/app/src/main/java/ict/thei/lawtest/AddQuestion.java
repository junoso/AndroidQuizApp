package ict.thei.lawtest;

import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AddQuestion extends AppCompatActivity {
    DatabaseHelper dbHelper;
    EditText editTextQuestion;
    EditText editTextOptionA;
    EditText editTextOptionB;
    EditText editTextOptionC;
    EditText editTextOptionD;
    Button buttonAdd, buttonDelete, buttonLoadData;
    RecyclerView recyclerView;
    QAAdapter qaAdapter;
    List<QAItem> qaList;
    Spinner spinnerCorrectAnswer, spinnerCategory;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_question);

        dbHelper = new DatabaseHelper(this);
        editTextQuestion = findViewById(R.id.editTextQuestion);
        editTextOptionA = findViewById(R.id.editTextOptionA);
        editTextOptionB = findViewById(R.id.editTextOptionB);
        editTextOptionC = findViewById(R.id.editTextOptionC);
        editTextOptionD = findViewById(R.id.editTextOptionD);
        buttonAdd = findViewById(R.id.buttonAdd);
        buttonDelete = findViewById(R.id.buttonDelete);
        recyclerView = findViewById(R.id.recyclerView);
        buttonLoadData = findViewById(R.id.buttonLoadData);

        // Initialize spinners
        spinnerCorrectAnswer = findViewById(R.id.spinnerCorrectAnswer);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.answer_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCorrectAnswer.setAdapter(adapter);

        spinnerCategory = findViewById(R.id.spinnerCategory);
        ArrayAdapter<CharSequence> categoryAdapter = ArrayAdapter.createFromResource(this,
                R.array.category_options, android.R.layout.simple_spinner_item);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(categoryAdapter);

        qaList = new ArrayList<>();
        qaAdapter = new QAAdapter(qaList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(qaAdapter);

        buttonAdd.setOnClickListener(v -> {
            String question = editTextQuestion.getText().toString();
            String optionA = editTextOptionA.getText().toString();
            String optionB = editTextOptionB.getText().toString();
            String optionC = editTextOptionC.getText().toString();
            String optionD = editTextOptionD.getText().toString();
            String correctAnswer = spinnerCorrectAnswer.getSelectedItem().toString();
            int category = spinnerCategory.getSelectedItemPosition() + 1;

            if (!question.isEmpty() && !optionA.isEmpty() && !optionB.isEmpty() && !optionC.isEmpty() && !optionD.isEmpty()) {
                dbHelper.addQA(question, optionA, optionB, optionC, optionD, correctAnswer, category);
                loadQAData();
                clearInputFields();
            }
        });

        buttonLoadData.setOnClickListener(v -> {
            loadDefaultQuestions();
        });

        buttonDelete.setOnClickListener(v -> {
            int position = qaAdapter.getSelectedPosition();
            if (position != -1) {
                dbHelper.deleteQA(qaList.get(position).getQuestion());
                qaAdapter.deleteItem(position);
            }
        });

        loadQAData();
    }

    private void loadQAData() {
        qaList.clear();
        Cursor cursor = dbHelper.getAllQA();

        if (cursor.moveToFirst()) {
            do {
                String question = cursor.getString(cursor.getColumnIndex("question"));
                String optionA = cursor.getString(cursor.getColumnIndex("option_a"));
                String optionB = cursor.getString(cursor.getColumnIndex("option_b"));
                String optionC = cursor.getString(cursor.getColumnIndex("option_c"));
                String optionD = cursor.getString(cursor.getColumnIndex("option_d"));
                String correctAnswer = cursor.getString(cursor.getColumnIndex("correct_answer"));
                int category = cursor.getInt(cursor.getColumnIndex("category"));

                QAItem qaItem = new QAItem(question, optionA, optionB, optionC, optionD, correctAnswer, category);
                qaList.add(qaItem);
            } while (cursor.moveToNext());
        }
        cursor.close();

        qaAdapter.notifyDataSetChanged();
    }

    private void loadDefaultQuestions() {
        List<String> questions = new ArrayList<>();

        try {
            InputStream is = getAssets().open("question.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));

            String line;
            while ((line = reader.readLine()) != null) {
                questions.add(line);
            }
            reader.close();
        } catch (IOException e) {
            Log.e("LoadQuestions", "Error reading questions file", e);
        }

        for (String data : questions) {
            String[] parts = data.split("\\|");
            if (parts.length == 6) {
                List<String> options = new ArrayList<>();
                options.add(parts[1]);
                options.add(parts[2]);
                options.add(parts[3]);
                options.add(parts[4]);

                Collections.shuffle(options);

                String correctAnswer = parts[1];
                if (options.get(0).equals(correctAnswer)) {
                    correctAnswer = "A";
                } else if (options.get(1).equals(correctAnswer)) {
                    correctAnswer = "B";
                } else if (options.get(2).equals(correctAnswer)) {
                    correctAnswer = "C";
                } else if (options.get(3).equals(correctAnswer)) {
                    correctAnswer = "D";
                }
                int category = Integer.parseInt(parts[5]);
                dbHelper.addQA(parts[0], options.get(0), options.get(1), options.get(2), options.get(3), correctAnswer, category);
            } else {
                Log.e("LoadQuestions", "Invalid question format: " + data);
            }
        }

        loadQAData(); // Refresh the displayed questions
        Toast.makeText(this, questions.size() + " Questions Loaded", Toast.LENGTH_SHORT).show();
    }

    private void clearInputFields() {
        editTextQuestion.setText("");
        editTextOptionA.setText("");
        editTextOptionB.setText("");
        editTextOptionC.setText("");
        editTextOptionD.setText("");
        spinnerCorrectAnswer.setSelection(0);
    }
}
