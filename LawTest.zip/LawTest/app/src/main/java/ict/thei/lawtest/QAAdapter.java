package ict.thei.lawtest;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class QAAdapter extends RecyclerView.Adapter<QAAdapter.QAViewHolder> {
    private List<QAItem> qaList;
    private int selectedPosition = -1;

    public QAAdapter(List<QAItem> qaList) {
        this.qaList = qaList;
    }

    @Override
    public QAViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(android.R.layout.simple_list_item_2, parent, false);
        return new QAViewHolder(view);
    }

    @Override
    public void onBindViewHolder(QAViewHolder holder, int position) {
        QAItem qaItem = qaList.get(position);
        holder.questionTextView.setText(qaItem.getQuestion());

        String correctAnswerText = "";
        switch (qaItem.getCorrectAnswer()) {
            case "A":
                correctAnswerText = "Correct Answer: A: " + qaItem.getOptionA();
                break;
            case "B":
                correctAnswerText = "Correct Answer: B: " + qaItem.getOptionB();
                break;
            case "C":
                correctAnswerText = "Correct Answer: C: " + qaItem.getOptionC();
                break;
            case "D":
                correctAnswerText = "Correct Answer: D: " + qaItem.getOptionD();
                break;
            default:
                correctAnswerText = "Correct Answer: Bug";
                break;
        }

        holder.answerTextView.setText(correctAnswerText);
        holder.itemView.setBackgroundColor(selectedPosition == position ? Color.LTGRAY : Color.TRANSPARENT);

        holder.itemView.setOnClickListener(v -> {
            selectedPosition = position;
            notifyDataSetChanged();
        });
    }

    @Override
    public int getItemCount() {
        return qaList.size();
    }

    public int getSelectedPosition() {
        return selectedPosition;
    }

    public void deleteItem(int position) {
        if (position >= 0 && position < qaList.size()) {
            qaList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, qaList.size());
        }
    }

    static class QAViewHolder extends RecyclerView.ViewHolder {
        TextView questionTextView;
        TextView answerTextView;

        public QAViewHolder(View itemView) {
            super(itemView);
            questionTextView = itemView.findViewById(android.R.id.text1);
            answerTextView = itemView.findViewById(android.R.id.text2);
        }
    }
}