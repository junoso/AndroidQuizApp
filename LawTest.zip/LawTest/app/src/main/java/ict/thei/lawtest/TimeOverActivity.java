package ict.thei.lawtest;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class TimeOverActivity extends AppCompatActivity {
    private TextView textViewTimeOver, textViewScore;
    private Button checkAnswer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_over);

        textViewTimeOver = findViewById(R.id.textViewTimeOver);
        textViewScore = findViewById(R.id.textViewScore);
        checkAnswer = findViewById(R.id.checkAnswer);

        // Get the score passed from QuizActivity
        Intent intent = getIntent();
        int score = intent.getIntExtra("SCORE", 0);
        textViewScore.setText("Your Score: " + score);

        checkAnswer.setOnClickListener(v -> {
            Intent retryIntent = new Intent(TimeOverActivity.this, QuizActivity.class);
            startActivity(retryIntent);
            finish();
        });
    }
}